/*
Iterables: https://www.w3schools.com/js/js_iterables.asp
Read the page
Demonstrate iteration of a list 
Create a list of movies, books, or games at least 5 items long and 
display them in the list paragraph
*/
let games = ["God of War", "Hogwarts Legacy", "Midnight Suns", "Civilization VI", "Elden Ring"]
let list = [];
for(const x of games){
    list += x + ", ";
}
document.getElementById("list").innerHTML = list;



/*
JS Sets

https://www.w3schools.com/js/js_sets.asp

Create a set with at least 5 song titles in it
display the contents of the set in the set1 paragraph (use iteration)

*/
let songs = new Set(["Sex and Candy", "Big Iron", "Ring of Fire", "Lake of Fire", "Fireworks"])
let set = []
for(const x of songs){
    set += x + ", ";
}
document.getElementById("set1").innerHTML = set;

// add two more songs to the set then display in the set2
songs.add("Happy Birthday");
songs.add("Private Eyes");
let set2 = []
for(const x of songs){
    set2 += x + ", ";
}
document.getElementById("set2").innerHTML = set2;





/* 
Maps
https://www.w3schools.com/js/js_maps.asp

Maps are like dictionaries in python
Create a map with five names and emails in it.
Display the contents of the map in map1 use the forEach() method (bottom of
    the reference page)
*/
let emails = new Map([
    ["Dani", "danibobani@yahoo.com"],
    ["Maria", "mariagomez00@gmail.com"],
    ["Monica", "moneymoni@sbcglobal.net"],
    ["Grace", "grace.c.evan@yahoo.com"],
    ["Joe", "joeschmo@gmail.com"]
])

let contacts = "";
emails.forEach (function(value, key) {
  contacts += key + ' = ' + value + "<br>";
})

document.getElementById("map1").innerHTML = contacts;
// add two new names and emails and display in map2 use the forEach() method
let contacts2 = "";
emails.set("Ayleen", "avela34@outlook.com")
emails.set("Arnold", "heyarnold@thebomb.com")
emails.forEach (function(value, key) {
  contacts2 += key + ' = ' + value + "<br>";
})
document.getElementById("map2").innerHTML = contacts2;



// get and display the email of one person, display in map3

let person = emails.get("Arnold")
document.getElementById("map3").innerHTML = person;
