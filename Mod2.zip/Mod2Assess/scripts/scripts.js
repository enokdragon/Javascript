function setValue(){
    document.getElementById("name").value = "";
    document.getElementById("sprite").value = 0;
    document.getElementById("chercoke").value = 0;
    document.getElementById("pinfan").value = 0;
    document.getElementById("tea").value = 0;
    document.getElementById("chocomilk").value = 0;
    document.getElementById("cuban").value = 0;
    document.getElementById("pastrami").value = 0;
    document.getElementById("chicken").value = 0;
    document.getElementById("turkey").value = 0;
    document.getElementById("cheese").value = 0;
    document.getElementById("fries").value = 0;
    document.getElementById("slaw").value = 0;
    document.getElementById("chips").value = 0;
    document.getElementById("donuts").value = 0;
    document.getElementById("icecream").value = 0;
}
function getTotal(){
    let name = document.getElementById("name").value;
    let sprite = parseFloat(document.getElementById("sprite").value);
    let chercoke = parseFloat(document.getElementById("chercoke").value);
    let pinfan = parseFloat(document.getElementById("pinfan").value);
    let tea = parseFloat(document.getElementById("tea").value);
    let chocomilk = parseFloat(document.getElementById("chocomilk").value);
    let cuban = parseFloat(document.getElementById("cuban").value);
    let pastrami = parseFloat(document.getElementById("pastrami").value);
    let chicken = parseFloat(document.getElementById("chicken").value);
    let turkey = parseFloat(document.getElementById("turkey").value);
    let cheese = parseFloat(document.getElementById("cheese").value);
    let fries = parseFloat(document.getElementById("fries").value);
    let slaw = parseFloat(document.getElementById("slaw").value);
    let chips = parseFloat(document.getElementById("chips").value);
    let donuts = parseFloat(document.getElementById("donuts").value);
    let icecream = parseFloat(document.getElementById("icecream").value);
    let drinkTotal = sprite + chercoke + pinfan + tea + chocomilk;
    let drink_cost = drinkTotal * 1.00;
    document.getElementById("drink_sub").innerHTML = name + " wants " + drinkTotal + " drinks. It will cost $" + drink_cost;
    let sammyTotal = cuban + pastrami + chicken + turkey + cheese;
    let sammy_cost = (cuban *7) + (pastrami * 6) + (chicken * 5) + (turkey * 5) + (cheese * 2.5)
    if (sammyTotal>0){
        document.getElementById("sammy_sub").innerHTML = name + " wants " + sammyTotal + " sandwiches. It will cost $" + sammy_cost;    
    }
    let extraTotal = fries + slaw + chips + donuts + icecream;
    let extra_cost = (fries * 1.5) + (slaw * 1.5) + (chips * 1.5) +(donuts * 2.5) + (icecream * 3.5)
    if (extraTotal>0){
        document.getElementById("extra_sub").innerHTML = name + " wants " + extraTotal + " extras. It will cost $" + extra_cost;
    }
    let final_cost = sammy_cost + drink_cost + extra_cost;
    document.getElementById("final").innerHTML = name + "'s final cost is " + final_cost + "$";
}