$(document).ready(function(){
    $("#submit").click (function(event) {
        event.preventDefault();
    

        var line = $("#fname").val();       //add all values to line variable
        line = line + " " + $("#lname").val() + ",";
        line = line + " " + $("#guests").val() + " guests,";
        line = line + " " + $("#dish").val();
        line = line + " ,bringing " + $("#servings").val() + " servings <br>";

        $("#plan").append(line);        //append line to plan paragraph 

        $("#fname").val("");      // set all values back to null/empty
        $("#lname").val("")
        $("#guests").val("");  
        $("#dish").val(""); 
        $("#servings").val(""); 


    });

    $("#light").click(function(){
        $("h1, h2, h3").addClass("primaryHeadings")
        $("h1, h2, h3").removeClass("secondaryHeadings")
        $("main").addClass("light");
        $("main").removeClass("dark");
    })

    $("#dark").click(function(){
        $("h1, h2, h3").removeClass("primaryHeadings");
        $("h1, h2, h3").addClass("secondaryHeadings");
        $("main").removeClass("light");
        $("main").addClass("dark");
    })

    $("#larger").click(function(){
        var currentFontSize = parseInt($("#primary").css('font-size'));
        currentFontSize += 3;
        setFont = currentFontSize + "px"
        $("#primary").css("fontSize", setFont)
    })    

    $("#smaller").click(function(){
        var currentFontSize = parseInt($("#primary").css('font-size'));
        currentFontSize -= 3;
        setFont = currentFontSize + "px"
        $("#primary").css("fontSize", setFont)
    })  
});

