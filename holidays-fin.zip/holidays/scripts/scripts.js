/*let selection = document.getElementById("month")
let selectionValue = selection.value

//document.getElementById("submit").addEventListener("click", function(selectionValue)){
//    document.getElementById("display").innerHTML = selectionValue;

//};

function HoliDisplay(selectionValue){
    if(selectionValue === "January"){
        document.getElementById("display").innerHTML = "";
    } 
}*/
//^^^ this is me confusing myself and over-complicating things but it feels bad to delete it

let months = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
let output = "";

for(let month of months){
    switch(month){
        case "jan":
            document.getElementById("jan").innerHTML = "Jan 1, New Year's Day<br>Jan 16, MLK Birthday"
            
            break;
        case "feb":
            document.getElementById("feb").innerHTML = "Feb 14, Valentine's Day<br>Feb 21, Mardi Gras"
            
            break;
        case "mar":
            document.getElementById("mar").innerHTML = "March 8, National Women's Day<br>March 17, St. Patrick's Day"
           
            break;
        case "apr":
            document.getElementById("apr").innerHTML = "April 1, April Fool's<br>April 9, Easter Sunday"
            
            break;
        case "may":
            document.getElementById("may").innerHTML = "May 2, National Teacher's Day<br>May 29, Memorial Day"
            
            break;
        case "jun":
            document.getElementById("jun").innerHTML = "June 18, Father's Day<br>June 21, Summer Solstice"
            
            break;
        case "jul":
            document.getElementById("jul").innerHTML = "July 4, Independence Day<br>July 5, National Bikini Day"
            
            break;
        case "aug":
            document.getElementById("aug").innerHTML = "August 1, National Mountain CLimbing day<br>August 13, Left Hander's Day"
            
            break;
        case "sep":
            document.getElementById("sep").innerHTML = "September 4, Labor Day<br>September 15, Rosh Hashanah"
            
            break;
        case "oct":
            document.getElementById("oct").innerHTML = "October 4, Yom Kippur<br>October 31, Halloween"
            
            break;
        case "nov":
            document.getElementById("nov").innerHTML = "November 11, Veterans Day<br>November 23, Thanksgiving"
            
            break;
        case "dec":
            document.getElementById("dec").innerHTML = "December 7, Pearl Harbor Day<br>December 21, Winter Solstice"
            
            break;
        default:
            document.getElementById("display").innerHTML = "This is wrong";


    }



}
//document.getElementById("display").innerHTML = output + 1;


