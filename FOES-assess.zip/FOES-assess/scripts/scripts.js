const fruit1 = {
    name: "Apple",
    category: "Pome fruit",
    image: "images/apple.jpg",
    taste: "Typically sweet and crisp, the more yellow the variety the more sour.",
    origin: "Central Asia"
};
const fruit2 = {
    name: "Berries",
    category: "Berry fruit",
    image: "images/berries.jpg",
    taste: "Fleshy and sweet, they come in different varieties.",
    origin: "Temperate regions across the world"
};
const fruit3 = {
    name: "Oranges",
    category: "Citrus fruit",
    image: "images/oranges.jpg",
    taste: "Sweet, juicy, and tart; often made into juice.",
    origin: "All citrus fruits originated in the Southeastern Himalayan foothills."

};
const fruit4 = {
    name: "Pears",
    category: "Pome fruit",
    image: "images/pears.jpg",
    taste: "Pears manage to cover a wide variety of flavor profiles.",
    origin: "Pears originated in the Southeastern Europe and were loved by Greeks and Romans."

};
const fruit5 = {
    name: "Strawberries",
    category: "false fruit",
    image: "images/strawberries.jpg",
    taste: "Sweet and fragrant.",
    origin: "Northern Europe."

};


function display(){
    let html = `<h2>${fruit1.name}</h2>` +
                `<h3>Type:</h3>` +
                `<h3>${fruit1.category}</h3>`
                 + `<img src= ${fruit1.image}>` +
                `<h3>Taste:</h3>` +
                `<p>${fruit1.taste}</p>` + `<h3>Origin:</h3>` +
                `<p>${fruit1.origin}</p>`;

    document.getElementById('ob1').innerHTML = html;

    let object2 = `<h2>${fruit2.name}</h2>` +
                    `<h3>Type:</h3>` +
                    `<h3>${fruit2.category}</h3>`
                     + `<img src= ${fruit2.image}>` +
                    `<h3>Taste:</h3>` +
                    `<p>${fruit2.taste}</p>` + `<h3>Origin:</h3>` +
                    `<p>${fruit2.origin}</p>`;
    
    document.getElementById("ob2").innerHTML = object2;

    let object3 = `<h2>${fruit3.name}</h2>` +
                    `<h3>Type:</h3>` +
                    `<h3>${fruit3.category}</h3>`
                     + `<img src= ${fruit3.image}>` +
                    `<h3>Taste:</h3>` +
                    `<p>${fruit3.taste}</p>` + `<h3>Origin:</h3>` +
                    `<p>${fruit3.origin}</p>`;
    
    document.getElementById("ob3").innerHTML = object3;

    let object4 = `<h2>${fruit4.name}</h2>` +
                    `<h3>Type:</h3>` +
                    `<h3>${fruit4.category}</h3>`
                     + `<img src= ${fruit4.image}>` +
                    `<h3>Taste:</h3>` +
                    `<p>${fruit4.taste}</p>` + `<h3>Origin:</h3>` +
                    `<p>${fruit4.origin}</p>`;
    
    document.getElementById("ob4").innerHTML = object4;

    let object5 = `<h2>${fruit5.name}</h2>` +
                    `<h3>Type:</h3>` +
                    `<h3>${fruit5.category}</h3>`
                     + `<img src= ${fruit5.image}>` +
                    `<h3>Taste:</h3>` +
                    `<p>${fruit5.taste}</p>` + `<h3>Origin:</h3>` +
                    `<p>${fruit5.origin}</p>`;
    
    document.getElementById("ob5").innerHTML = object5;
}