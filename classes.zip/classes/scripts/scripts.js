class Day{
    constructor(weather, weekDay, season, workDay){
        this.weather = weather;
        this.weekDay = weekDay;
        this.season = season;
        this.workDay = workDay;
    }

    dayStats() {
        return 'The weather is ' + this.weather + ' on this ' + this.season + ' ' + this.weekDay + ' and do I have to work?.. looks like ' + this.workDay;
    }
}

const dayOne = new Day('sunny', 'monday', 'spring', 'no')
//console.log(dayOne); works here but having trouble figuring out how to display
document.getElementById("day1").innerHTML = dayOne.dayStats(); //working

const dayTwo = new Day('hailing', 'wednesday', 'autumn', 'yes')
document.getElementById("day2").innerHTML = dayTwo.dayStats();

const dayThree = new Day('rainy', 'friday', 'summer', 'no')
document.getElementById("day3").innerHTML = dayThree.dayStats();

const dayFour = new Day('overcast', 'sunday', 'winter', 'sadly yes')
document.getElementById("day4").innerHTML = dayFour.dayStats();
