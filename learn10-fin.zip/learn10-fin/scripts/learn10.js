function start() {
    // Math: https://www.w3schools.com/js/js_math.asp
    // Demonstrate the use of round, ceil, floor, trunc, sign
    // pow, min, and random and display to the appropriate paragraphs
    document.getElementById("ceil").innerHTML = Math.ceil(7.1);
    document.getElementById("round").innerHTML = Math.round(7.1);
    document.getElementById("floor").innerHTML = Math.floor(7.1);
    document.getElementById("trunc").innerHTML = Math.trunc(-7.1);
    document.getElementById("sign").innerHTML = Math.sign(0);
    document.getElementById("pow").innerHTML = Math.pow(7.1, 3);
    document.getElementById("min").innerHTML = Math.min(7.1, 0.1, 3, 5, 19);
    document.getElementById("random").innerHTML = Math.random() * 10;






    // Random: https://www.w3schools.com/js/js_random.asp
    // create a random integer between 1 and 100 and display in the random2 paragraph
    const rand = Math.random()
    document.getElementById("random2").innerHTML = Math.round(rand * 100);


    // Booleans: https://www.w3schools.com/js/js_booleans.asp
    // read the reference
    

    // Comparisons: https://www.w3schools.com/js/js_comparisons.asp
    // demonstrate and explain the difference between == and === in the
    // comparisons paragraph
    document.getElementById("comparisons").innerHTML = "The difference between == and ===: == is used to compare the values of a variable and is not nearly as strict as ===. === compares a variables type and value to make sure they are exactly the same; therefore, comparing a string and a integer will never yield a true result";


    // Conditions: https://www.w3schools.com/js/js_if_else.asp
    // Read the conditions page
}