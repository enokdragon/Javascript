function addDate(){
    let today = new Date();
    document.getElementById("myDate").innerHTML = today;
    document.getElementById("name").value = "";
    document.getElementById("rooms").value = "1";
    document.getElementById("rm1length").value = "";
    document.getElementById("rm1width").value = "";
    document.getElementById("rm1height").value = "";
    document.getElementById("rm1cost").value = "";
}

function estimate() {
    roomAmt = document.getElementById("rooms").value;
    if (roomAmt == 1){
        let name = document.getElementById("name").value;
        let length = parseFloat(document.getElementById("rm1length").value);
        let width = parseFloat(document.getElementById("rm1width").value);
        let height = parseFloat(document.getElementById("rm1height").value);
        let SqFt1 = (length * height * 2) + (length * width * 2);
        let cost = (SqFt1 * .65);
        var totalCost = cost; 
        document.getElementById("rm1cost").value = cost;
    }
    else if (roomAmt == 2){  
        let length = parseFloat(document.getElementById("rm1length").value);
        let width = parseFloat(document.getElementById("rm1width").value);
        let height = parseFloat(document.getElementById("rm1height").value);
        let SqFt1 = (length * height * 2) + (length * width * 2);
        let cost = (SqFt1 * .65);
        document.getElementById("rm1cost").value = cost;

        let length2 = parseFloat(document.getElementById("rm2length").value);
        let width2 = parseFloat(document.getElementById("rm2width").value);
        let height2 = parseFloat(document.getElementById("rm2height").value);
        let SqFt2 = (length2 * height2 * 2) + (length2 * width2 * 2);
        let cost2 = (SqFt2 * .65);
        var totalCost = cost + cost2; 
        document.getElementById("rm2cost").value = cost2;
    }
    else if(roomAmt == 3){  
        let length = parseFloat(document.getElementById("rm1length").value);
        let width = parseFloat(document.getElementById("rm1width").value);
        let height = parseFloat(document.getElementById("rm1height").value);
        let SqFt1 = (length * height * 2) + (length * width * 2);
        let cost = (SqFt1 * .65);
        document.getElementById("rm1cost").value = cost;

        let length2 = parseFloat(document.getElementById("rm2length").value);
        let width2 = parseFloat(document.getElementById("rm2width").value);
        let height2 = parseFloat(document.getElementById("rm2height").value);
        let SqFt2 = (length2 * height2 * 2) + (length2 * width2 * 2);
        let cost2 = (SqFt2 * .65);
        document.getElementById("rm2cost").value = cost2;
        
        let length3 = parseFloat(document.getElementById("rm2length").value);
        let width3 = parseFloat(document.getElementById("rm2width").value);
        let height3 = parseFloat(document.getElementById("rm2height").value);
        let SqFt3 = (length3 * height3 * 2) + (length3 * width3 * 2);
        let totalSqFt = SqFt1 + SqFt2 + SqFt3;
        let cost3 = (totalSqFt * .65);
        var totalCost = cost + cost2 + cost3; 
        document.getElementById("rm3cost").value = cost3;
    }
    /*

        let length2 = parseFloat(document.getElementById("rm2length").value);
        let width2 = parseFloat(document.getElementById("rm2width").value);
        let height2 = parseFloat(document.getElementById("rm2height").value);
        let SqFt2 = (length2 * height2 * 2) + (length2 * width2 * 2);
        let length3 = parseFloat(document.getElementById("rm2length").value);
        let width3 = parseFloat(document.getElementById("rm2width").value);
        let height3 = parseFloat(document.getElementById("rm2height").value);
        let SqFt3 = (length3 * height3 * 2) + (length3 * width3 * 2);
        let totalSqFt = SqFt1 + SqFt2 + SqFt3;
        let cost = (totalSqFt * .65); 
    document.getElementById("rm1cost").value = cost;
    
    document.getElementById("rm2cost").value = cost;
    document.getElementById("rm3cost").value = cost;
*/
    
    
    let name = document.getElementById("name").value;
    document.getElementById("estimate").innerHTML = name + " your estimate is " + totalCost + "$";
} 

function showScreen() {
    roomAmt = document.getElementById("rooms").value;
    if (roomAmt == "2"){
        document.getElementById("room2").style.display = "block";
    }
    else if (roomAmt == "3"){
        document.getElementById("room2").style.display = "block";
        document.getElementById("room3").style.display = "block";
    }
/*    document.getElementById("rm2length").value = "";
    document.getElementById("rm2width").value = "";
    document.getElementById("rm2height").value = "";
    document.getElementById("rm2cost").value = "";
*/
}