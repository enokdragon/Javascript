


alert("Please note: If you are 16 you will need a signed permission slip from a parent")

let eligiblePeople = [];
// will add each persons name to an array

document.getElementById("submit").addEventListener("click", function(event){

    event.preventDefault();

    let age = document.getElementById("age").value;
    let height = document.getElementById("height").value;
    let weight = document.getElementById("weight").value;
    let sex = document.getElementById("sex").value;
    let food = document.getElementById("food").value;
    let name = document.getElementById("name").value;
    let passed = "You are eligible congratulations, please continue on to screening";
    let failed = "Sorry you don't have a high enough Total Blood Volume to donate";


    const Person = {Age:Number(age), Height:Number(height), Weight:Number(weight), Sex:sex, Food:food, Name:name};
    //makes sure that when height is read by the switch statement correctly

    if(Person.Food=="yes"){// checks for if they have eaten

        if(Person.Age<16){     //verifies eligible age
            alert("You are not eligible, try again when your 16 and have a signed sheet from a parent");
        }
        else{
            
            if(Person.Sex=="male"){        //different requirements for men and women

                //alert("hehe")//testing
            
                if(Person.Weight >= 110 && Person.Height >= 60){
                    //alert("you're a winner, but not really")// testing
                    document.getElementById("elig").innerHTML = passed;
                    eligiblePeople += Person.Name + ", ";
                }
                else{
                    document.getElementById("elig").innerHTML = failed
                }
            }
    
            
            
            else if(Person.Sex=="female"){  //passes eligibility value to the main page
                if(Person.Height <= 57){
                    document.getElementById("elig").innerHTML = failed;
                }
                else if(Person.Height >= 66){
                    document.getElementById("elig").innerHTML = passed;
                    eligiblePeople += Person.Name + ", ";

                }
                else if(Person.Height < 66 && Person.Height > 57){
                    switch(Person.Height){
                        case 58:
                            if(Person.Weight < 146){
                                document.getElementById("elig").innerHTML = failed;
                            }
                            else{
                                document.getElementById("elig").innerHTML = passed
                                eligiblePeople += Person.Name + ", ";
                            }
                            break;
                        case 59:
                            if(Person.Weight < 142){
                                document.getElementById("elig").innerHTML = failed;
                            }
                            else{
                                document.getElementById("elig").innerHTML = passed
                                eligiblePeople += Person.Name + ", ";
                            }
                            break;
                        case 60:
                            if(Person.Weight < 138){
                                document.getElementById("elig").innerHTML = failed;
                            }
                            else{
                                document.getElementById("elig").innerHTML = passed
                                eligiblePeople += Person.Name + ", ";
                            }
                            break;
                        case 61:
                            if(Person.Weight < 133){
                                document.getElementById("elig").innerHTML = failed;
                            }
                            else{
                                document.getElementById("elig").innerHTML = passed
                                eligiblePeople += Person.Name + ", ";
                            }
                            break;
                        case 62:
                            if(Person.Weight <= 129){
                                document.getElementById("elig").innerHTML = failed;
                            }
                            else{
                                document.getElementById("elig").innerHTML = passed
                                eligiblePeople += Person.Name + ", ";
                            }
                            break;
                        case 63:
                            if(weight <= 124){
                                document.getElementById("elig").innerHTML = failed;
                            }
                            else{
                                document.getElementById("elig").innerHTML = passed
                                eligiblePeople += Person.Name + ", ";
                            }
                            break;
                        case 64:
                            if(Person.Weight <= 120){
                                document.getElementById("elig").innerHTML = failed;
                            }
                            else{
                                document.getElementById("elig").innerHTML = passed
                                eligiblePeople += Person.Name + ", ";
                            }
                            break;
                        case 65:
                            if(Person.Weight < 115){
                                document.getElementById("elig").innerHTML = failed;
                            }
                            else{
                                document.getElementById("elig").innerHTML = passed
                                eligiblePeople += Person.Name + ", ";
                            }
                            break;
                        default:
                            alert("Please enter your height in only inches.")
                            break;
                    }
                }
                else{
                    document.getElementById("elig").innerHTML = failed;
                    //alert("invalid input fro height") used for testing
                }
            }
            else{
                alert("Please type your assigned sex at birth if you have not undergone sex changing surgery for safety purposes (male or female")
            }
        }
        
            }
    else{
            alert("Go grab some hearty food and come back!")
    }

    document.getElementById("list").innerHTML = eligiblePeople; //display global array of eligible people
});

