let random =  Math.random() * 999;
random = Math.round(random);
alert(Math.round(random)); // test random 
let pastCloseness = 0;
document.getElementById("submit").addEventListener("click", function(event){
    event.preventDefault();
    let guess = document.getElementById("guess").value; //retrieve guess from user
    let closeness = Math.abs(random - guess);   
    
    if(pastCloseness > closeness){
        document.getElementById("status").innerHTML = "getting warmer...";
    }else if(pastCloseness<closeness){
        document.getElementById("status").innerHTML = "getting colder...";

    }


    if(guess == random){
        document.getElementById("win").innerHTML = "YOU WIN";
    }

    

    if(closeness > 250){
        document.getElementById("message").innerHTML = "FREEZING";
        //document.body.style.backgroundColor = "darkblue";
        let color = "darkblue";
        changeBg(color);
    }
    else if(closeness > 200){
        document.getElementById("message").innerHTML = "REAL COLD";
        //document.body.style.backgroundColor = "blue";
        let color = "blue";
        changeBg(color);
    }
    else if(closeness > 150){
        document.getElementById("message").innerHTML = "COLD";
        //document.body.style.backgroundColor = "lightblue";
        let color = "lightblue";
        changeBg(color);
    }
    else if(closeness > 100){
        document.getElementById("message").innerHTML = "WARM";
        //document.body.style.backgroundColor = "orange";
        let color = "orange";
        changeBg(color);
    }
    else if(closeness > 50){
        document.getElementById("message").innerHTML = "HOT";
        //document.body.style.backgroundColor = "red";
        let color = "red";
        changeBg(color);
    }
    else if(closeness < 25){
        document.getElementById("message").innerHTML = "BURNIN' UP";
        //document.body.style.backgroundColor = "darkred";
        let color = "darkred";
        changeBg(color);

    }
    else if(closeness === 0){
        win(guess, random);
    }

   
    //document.getElementById("win").innerHTML = "YOU WIN";
    

    //while(document.getElementById("win"))
    

    
    let pastGuess = guess;
    pastCloseness = Math.abs(random - pastGuess);
    
    document.getElementById("guess").value = ''; //would this reset value to null
    
    
});
function lose(){
    document.getElementById("win").innerHTML = "You lose"
}

function changeBg(color){
    document.body.style.backgroundColor = color;
}
/*function win(guess, random){
    if(guess === random){
        document.getElementById("win").innerHTML = "YOU WIN";   
    }
}*/
